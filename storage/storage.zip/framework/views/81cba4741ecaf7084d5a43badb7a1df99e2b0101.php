<?php $__env->startSection('navbar'); ?>
    <div class="layout-menu-toggle navbar-nav align-items-xl-center me-3 me-xl-0 d-xl-none">
        <a class="nav-item nav-link px-0 me-xl-4" href="javascript:void(0)">
            <i class="bx bx-menu bx-sm"></i>
        </a>
    </div>

    <div class="navbar-nav-right d-flex align-items-center" id="navbar-collapse">
        <div class="navbar-nav align-items-center" style="color: #007bff; font-size: 20px; font-weight:bold">Peningkatan</div>

        <ul class="navbar-nav flex-row align-items-center ms-auto">
            <!-- User -->
            <li class="nav-item navbar-dropdown dropdown-user dropdown">
                <a class="nav-link dropdown-toggle hide-arrow" href="javascript:void(0);" data-bs-toggle="dropdown">
                    <div class="avatar avatar-online">
                        <img src="<?php echo e(asset('sneat/assets/img/avatars/1.png')); ?>" alt
                            class="w-px-40 h-auto rounded-circle" />
                    </div>
                </a>
                <ul class="dropdown-menu dropdown-menu-end">
                    <li>
                        <a class="dropdown-item" href="#">
                            <div class="d-flex">
                                <div class="flex-shrink-0 me-3">
                                    <div class="avatar avatar-online">
                                        <img src="<?php echo e(asset('sneat/assets/img/avatars/1.png')); ?>" alt
                                            class="w-px-40 h-auto rounded-circle" />
                                    </div>
                                </div>
                                <div class="flex-grow-1">
                                    <span class="fw-semibold d-block">John Doe</span>
                                    <small class="text-muted">Admin</small>
                                </div>
                            </div>
                        </a>
                    </li>
                    <li>
                        <div class="dropdown-divider"></div>
                    </li>
                    <li>
                        <a class="dropdown-item" href="#">
                            <i class="bx bx-user me-2"></i>
                            <span class="align-middle">My Profile</span>
                        </a>
                    </li>
                    <li>
                        <a class="dropdown-item" href="#">
                            <i class="bx bx-cog me-2"></i>
                            <span class="align-middle">Settings</span>
                        </a>
                    </li>
                    <li>
                        <div class="dropdown-divider"></div>
                    </li>
                    <li>
                        <a class="dropdown-item" href="<?php echo e(route('logout')); ?>">
                            <i class="bx bx-power-off me-2"></i>
                            <span class="align-middle">Log Out</span>
                        </a>
                    </li>
                </ul>
            </li>
            <!--/ User -->
        </ul>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <h5 class="card-header">Peningkatan Standar Yang Ditetapkan Institusi</h5>
        <div class="table text-nowrap" id="horizontal-example">
            <table class="table">
                <thead class="table-purple">
                    <tr>
                        <th>No</th>
                        <th style="padding-left: 20px">Nama Dokumen</th>
                        <th>Peningkatan Standar</th>
                        <th style="padding-left: 30px">Tautan Dokumen Peningkatan</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody class="table-border-bottom-0">
                    
                    <tr>
                        <td>1</td>
                        <td class=" me-3" style="font-size: 13px">Pengaturan Standar Pendidikan Universitas Trunojoyo
                            Madura</td>
                            <?php
                            // Ambil data file dari tabel file_p5 berdasarkan id_fp5
                            $file1 = DB::table('file_p5')->where('id_fp5', 1)->value('files');
                        ?>

                        <td style="padding-left: 15px">
                            <input type="radio" name="selected_item1" value="Ada" <?php echo e(($file1 && $file1 !== '') ? 'checked' : ''); ?>> Ada
                            <span></span>
                            <input type="radio" name="selected_item1" value="Tidak Ada" style="margin-left: 1em" <?php echo e((!$file1 || $file1 === '') ? 'checked' : ''); ?>> Tidak Ada
                        </td>
                        <td style="padding-left: 90px">
                            <?php if($file1 && $file1 !== ''): ?>
                                <span class="badge bg-label-info me-1">Dokumen</span>
                            <?php else: ?>
                                <span class="me-1">Masih Dalam Proses</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <div class="dropdown">
                                <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown">
                                    <i class="bx bx-dots-vertical-rounded"></i>
                                </button>
                                <div class="dropdown-menu">
                                    <a class="dropdown-item" href="<?php echo e(route('editDokumenPeningkatan', 1)); ?>"><i
                                            class="bx bx-edit-alt me-1"></i>
                                        Ubah</a>
                                    <form method="POST"
                                        action="<?php echo e(route('hapusDokumenPeningkatan', 1)); ?>">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button class="dropdown-item btn btn-outline-danger"><i
                                                class="bx bx-trash me-1"></i>
                                            Hapus</button>
                                    </form>
                                </div>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td>2</td>
                        <td class=" me-3" style="font-size: 13px">Pengaturan Standar Penelitian Universitas Trunojoyo
                            Madura</td>
                            <?php
                                // Ambil data file dari tabel file_p5 berdasarkan id_fp5
                                $file2 = DB::table('file_p5')->where('id_fp5', 2)->value('files');
                            ?>

                            <td style="padding-left: 15px">
                                <input type="radio" name="selected_item2" value="Ada" <?php echo e(($file2 && $file2 !== '') ? 'checked' : ''); ?>> Ada
                                <span></span>
                                <input type="radio" name="selected_item2" value="Tidak Ada" style="margin-left: 1em" <?php echo e((!$file2 || $file2 === '') ? 'checked' : ''); ?>> Tidak Ada
                            </td>
                        <td style="padding-left: 90px">
                            <?php if($file2 && $file2 !== ''): ?>
                                <span class="badge bg-label-info me-1">Dokumen</span>
                            <?php else: ?>
                                <span class="me-1">Masih Dalam Proses</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <div class="dropdown">
                                <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown">
                                    <i class="bx bx-dots-vertical-rounded"></i>
                                </button>
                                <div class="dropdown-menu">
                                    <a class="dropdown-item" href="<?php echo e(route('editDokumenPeningkatan', 2)); ?>"><i class="bx bx-edit-alt me-1"></i>
                                        Ubah</a>
                                    <form method="POST"
                                        action="<?php echo e(route('hapusDokumenPeningkatan', 2)); ?>">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button class="dropdown-item btn btn-outline-danger"><i
                                                class="bx bx-trash me-1"></i>
                                            Hapus</button>
                                    </form>
                                </div>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td>3</td>
                        <td class=" me-3" style="font-size: 13px">Pengaturan Standar Pengabdian Kepada Masyarakat
                            Universitas Trunojoyo Madura</td>
                            <?php
                            // Ambil data file dari tabel file_p5 berdasarkan id_fp5
                            $file3 = DB::table('file_p5')->where('id_fp5', 3)->value('files');
                        ?>

                        <td style="padding-left: 15px">
                            <input type="radio" name="selected_item3" value="Ada" <?php echo e(($file3 && $file3 !== '') ? 'checked' : ''); ?>> Ada
                            <span></span>
                            <input type="radio" name="selected_item3" value="Tidak Ada" style="margin-left: 1em" <?php echo e((!$file3 || $file3 === '') ? 'checked' : ''); ?>> Tidak Ada
                        </td>
                        <td style="padding-left: 90px">
                            <?php if($file3 && $file3 !== ''): ?>
                                <span class="badge bg-label-info me-1">Dokumen</span>
                            <?php else: ?>
                                <span class="me-1">Masih Dalam Proses</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <div class="dropdown">
                                <button type="button" class="btn p-0 dropdown-toggle hide-arrow"
                                    data-bs-toggle="dropdown">
                                    <i class="bx bx-dots-vertical-rounded"></i>
                                </button>
                                <div class="dropdown-menu">
                                    <a class="dropdown-item" href="<?php echo e(route('editDokumenPeningkatan', 3)); ?>"><i
                                            class="bx bx-edit-alt me-1"></i>
                                        Ubah</a>
                                    <form method="POST"
                                        action="<?php echo e(route('hapusDokumenPeningkatan', 3)); ?>">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button class="dropdown-item btn btn-outline-danger"><i
                                                class="bx bx-trash me-1"></i>
                                            Hapus</button>
                                    </form>
                                </div>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td>4</td>
                        <td class=" me-3" style="font-size: 13px">Standar di aspek lainnya</td>
                        <?php
                            // Ambil data file dari tabel file_p5 berdasarkan id_fp5
                            $file4 = DB::table('file_p5')->where('id_fp5', 4)->value('files');
                        ?>

                        <td style="padding-left: 15px">
                            <input type="radio" name="selected_item4" value="Ada" <?php echo e(($file4 && $file4 !== '') ? 'checked' : ''); ?>> Ada
                            <span></span>
                            <input type="radio" name="selected_item4" value="Tidak Ada" style="margin-left: 1em" <?php echo e((!$file4 || $file4 === '') ? 'checked' : ''); ?>> Tidak Ada
                        </td>
                        <td style="padding-left: 90px">
                            <?php if($file4 && $file4 !== ''): ?>
                                <span class="badge bg-label-info me-1">Dokumen</span>
                            <?php else: ?>
                                <span class="me-1">Masih Dalam Proses</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <div class="dropdown">
                                <button type="button" class="btn p-0 dropdown-toggle hide-arrow"
                                    data-bs-toggle="dropdown">
                                    <i class="bx bx-dots-vertical-rounded"></i>
                                </button>
                                <div class="dropdown-menu">
                                    <a class="dropdown-item" href="<?php echo e(route('editDokumenPeningkatan', 4)); ?>"><i
                                            class="bx bx-edit-alt me-1"></i>Ubah</a>
                                    <form method="POST"
                                            action="<?php echo e(route('hapusDokumenPeningkatan', 4)); ?>">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button class="dropdown-item btn btn-outline-danger"><i
                                                    class="bx bx-trash me-1"></i>
                                                Hapus</button>
                                        </form>
                                </div>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td></td>
                        <td>
                            <li class=" me-3" style="font-size: 13px">Pengaturan Standar Layanan Kemahasiswaan
                                Universitas Trunojoyo Madura</li>
                        </td>
                        <?php
                            // Ambil data file dari tabel file_p5 berdasarkan id_fp5
                            $file5 = DB::table('file_p5')->where('id_fp5', 5)->value('files');
                        ?>

                        <td style="padding-left: 15px">
                            <input type="radio" name="selected_item5" value="Ada" <?php echo e(($file5 && $file5 !== '') ? 'checked' : ''); ?>> Ada
                            <span></span>
                            <input type="radio" name="selected_item5" value="Tidak Ada" style="margin-left: 1em" <?php echo e((!$file5 || $file5 === '') ? 'checked' : ''); ?>> Tidak Ada
                        </td>
                        <td style="padding-left: 90px">
                            <?php if($file5 && $file5 !== ''): ?>
                                <span class="badge bg-label-info me-1">Dokumen</span>
                            <?php else: ?>
                                <span class="me-1">Masih Dalam Proses</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <div class="dropdown">
                                <button type="button" class="btn p-0 dropdown-toggle hide-arrow"
                                    data-bs-toggle="dropdown">
                                    <i class="bx bx-dots-vertical-rounded"></i>
                                </button>
                                <div class="dropdown-menu">
                                    <a class="dropdown-item" href="<?php echo e(route('editDokumenPeningkatan', 5)); ?>"><i
                                            class="bx bx-edit-alt me-1"></i> Ubah</a>
                                    <form method="POST"
                                            action="<?php echo e(route('hapusDokumenPeningkatan', 5)); ?>">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button class="dropdown-item btn btn-outline-danger"><i
                                                    class="bx bx-trash me-1"></i>
                                                Hapus</button>
                                        </form>
                                </div>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td></td>
                        <td>
                            <li class=" me-3" style="font-size: 13px">Pengaturan Standar Layanan Kerjasama Universitas
                                Trunojoyo Madura</li>
                        </td>
                        <?php
                            // Ambil data file dari tabel file_p5 berdasarkan id_fp5
                            $file6 = DB::table('file_p5')->where('id_fp5', 6)->value('files');
                        ?>

                        <td style="padding-left: 15px">
                            <input type="radio" name="selected_item6" value="Ada" <?php echo e(($file6 && $file6 !== '') ? 'checked' : ''); ?>> Ada
                            <span></span>
                            <input type="radio" name="selected_item6" value="Tidak Ada" style="margin-left: 1em" <?php echo e((!$file6 || $file6 === '') ? 'checked' : ''); ?>> Tidak Ada
                        </td>
                        <td style="padding-left: 90px">
                            <?php if($file6 && $file6 !== ''): ?>
                                <span class="badge bg-label-info me-1">Dokumen</span>
                            <?php else: ?>
                                <span class="me-1">Masih Dalam Proses</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <div class="dropdown">
                                <button type="button" class="btn p-0 dropdown-toggle hide-arrow"
                                    data-bs-toggle="dropdown">
                                    <i class="bx bx-dots-vertical-rounded"></i>
                                </button>
                                <div class="dropdown-menu">
                                    <a class="dropdown-item" href="<?php echo e(route('editDokumenPeningkatan', 6)); ?>"><i
                                            class="bx bx-edit-alt me-1"></i> Ubah</a>
                                        <form method="POST"
                                            action="<?php echo e(route('hapusDokumenPeningkatan', 6)); ?>">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button class="dropdown-item btn btn-outline-danger"><i
                                                    class="bx bx-trash me-1"></i>
                                                Hapus</button>
                                        </form>
                                </div>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <td></td>
                        <td>
                            <li class="me-3" style="font-size: 13px">Pengaturan Standar Tata Kelola Universitas
                                Trunojoyo Madura</li>
                        </td>
                        <?php
                            // Ambil data file dari tabel file_p5 berdasarkan id_fp5
                            $file7 = DB::table('file_p5')->where('id_fp5', 7)->value('files');
                        ?>

                        <td style="padding-left: 15px">
                            <input type="radio" name="selected_item7" value="Ada" <?php echo e(($file7 && $file7 !== '') ? 'checked' : ''); ?>> Ada
                            <span></span>
                            <input type="radio" name="selected_item7" value="Tidak Ada" style="margin-left: 1em" <?php echo e((!$file7 || $file7 === '') ? 'checked' : ''); ?>> Tidak Ada
                        </td>
                        <td style="padding-left: 90px">
                            <?php if($file7 && $file7 !== ''): ?>
                                <span class="badge bg-label-info me-1">Dokumen</span>
                            <?php else: ?>
                                <span class="me-1">Masih Dalam Proses</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <div class="dropdown">
                                <button type="button" class="btn p-0 dropdown-toggle hide-arrow"
                                    data-bs-toggle="dropdown">
                                    <i class="bx bx-dots-vertical-rounded"></i>
                                </button>
                                <div class="dropdown-menu">
                                    <a class="dropdown-item" href="<?php echo e(route('editDokumenPeningkatan', 7)); ?>"><i
                                            class="bx bx-edit-alt me-1"></i> Ubah</a>
                                        <form method="POST"
                                            action="<?php echo e(route('hapusDokumenPeningkatan', 7)); ?>">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button class="dropdown-item btn btn-outline-danger"><i
                                                    class="bx bx-trash me-1"></i>
                                                Hapus</button>
                                        </form>
                                </div>
                            </div>
                        </td>
                    </tr>
                    
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\ProjectSIJAMUFIP-laravel9\SIJAMU_FIP\resources\views/User/admin/Peningkatan/index_peningkatan.blade.php ENDPATH**/ ?>