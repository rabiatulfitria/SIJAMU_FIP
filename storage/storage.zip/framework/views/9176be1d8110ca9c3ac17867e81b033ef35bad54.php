<?php $__env->startSection('tabel-unggah-dokumen'); ?>
<a href="/tambah-dokumen-pelaksanaan" class="btn btn-primary mb-3">Tambah Dokumen</a>
    <!-- Tabel yang akan ditampilkan -->
    <div id="DatatablesRenstraProgramStudinya">
        <!-- Tabel Kinerja Program Studi di sini -->
        <table class="table table-bordered custom-table-sm" >
                    <thead>
            <tr>
                <th>No</th>
                <th>Program Studi</th>
                <th>Dokumen Formulir Kepuasan</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $renstraProgramStudi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($index + 1); ?></td>
                    <td><?php echo e($document->nama_prodi); ?></td>
                    <td><a href="<?php echo e(asset('storage/' . $document->file)); ?>" target="_blank"><?php echo e($document->namafile); ?></a></td>
                    <td>
                        <a href="<?php echo e(url('/edit-dokumen-pelaksanaan/' . $document->id)); ?>" class="btn btn-warning btn-sm">Edit</a>
                        <form action="<?php echo e(route('deletePelaksanaan', $document->id)); ?>" method="POST" style="display: inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger btn-sm">Hapus</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        </table>
    </div>

    <div id="DatatablesKinerjaProgramStudinya">
        <!-- Tabel Kinerja Program Studi di sini -->
        <table class="table table-bordered custom-table-sm" >
                    <thead>
            <tr>
                <th>No</th>
                <th>Program Studi</th>
                <th>Dokumen Formulir Kepuasan</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $laporanKinerjaProgramStudi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($index + 1); ?></td>
                <td><?php echo e($document->nama_prodi); ?></td>
                <td><a href="<?php echo e(asset('storage/' . $document->file)); ?>" target="_blank"><?php echo e($document->namafile); ?></a></td>
                <td>
                    <a href="<?php echo e(url('/edit-dokumen-pelaksanaan/' . $document->id)); ?>" class="btn btn-warning btn-sm">Edit</a>
                    <form action="<?php echo e(route('deletePelaksanaan', $document->id)); ?>" method="POST" style="display: inline;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger btn-sm">Hapus</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        </table>
    </div>

    <div id="DatatablesKurikulum">
        <!-- Tabel Dokumen Kurikulum di sini -->
        <table class="table table-bordered custom-table-sm" >
                    <thead>
            <tr>
                <th>No</th>
                <th>Program Studi</th>
                <th>Dokumen Formulir Kepuasan</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $dokumenKurikulum; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($index + 1); ?></td>
                <td><?php echo e($document->nama_prodi); ?></td>
                <td><a href="<?php echo e(asset('storage/' . $document->file)); ?>" target="_blank"><?php echo e($document->namafile); ?></a></td>
                <td>
                    <a href="<?php echo e(url('/edit-dokumen-pelaksanaan/' . $document->id)); ?>" class="btn btn-warning btn-sm">Edit</a>
                    <form action="<?php echo e(route('deletePelaksanaan', $document->id)); ?>" method="POST" style="display: inline;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger btn-sm">Hapus</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        </table>
    </div>

    <div id="DatatablesRPS">
        <!-- Tabel RPS di sini -->
        <table class="table table-bordered custom-table-sm" >
                    <thead>
            <tr>
                <th>No</th>
                <th>Program Studi</th>
                <th>Dokumen Formulir Kepuasan</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $rps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($index + 1); ?></td>
                <td><?php echo e($document->nama_prodi); ?></td>
                <td><a href="<?php echo e(asset('storage/' . $document->file)); ?>" target="_blank"><?php echo e($document->namafile); ?></a></td>
                <td>
                    <a href="<?php echo e(url('/edit-dokumen-pelaksanaan/' . $document->id)); ?>" class="btn btn-warning btn-sm">Edit</a>
                    <form action="<?php echo e(route('deletePelaksanaan', $document->id)); ?>" method="POST" style="display: inline;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger btn-sm">Hapus</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        </table>
    </div>

    <div id="DatatablesMonitoring">
        <!-- Tabel Monitoring di sini -->
        <table class="table table-bordered custom-table-sm" >
                    <thead>
            <tr>
                <th>No</th>
                <th>Program Studi</th>
                <th>Dokumen Formulir Kepuasan</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $monitoringMbkm; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($index + 1); ?></td>
                <td><?php echo e($document->nama_prodi); ?></td>
                <td><a href="<?php echo e(asset('storage/' . $document->file)); ?>" target="_blank"><?php echo e($document->namafile); ?></a></td>
                <td>
                    <a href="<?php echo e(url('/edit-dokumen-pelaksanaan/' . $document->id)); ?>" class="btn btn-warning btn-sm">Edit</a>
                    <form action="<?php echo e(route('deletePelaksanaan', $document->id)); ?>" method="POST" style="display: inline;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger btn-sm">Hapus</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        </table>
    </div>
    <div id="DatatablesCPL">
        <!-- Tabel CPL di sini -->
        <table class="table table-bordered custom-table-sm" >
                    <thead>
            <tr>
                <th>No</th>
                <th>Program Studi</th>
                <th>Dokumen Formulir Kepuasan</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $cpl; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($index + 1); ?></td>
                <td><?php echo e($document->nama_prodi); ?></td>
                <td><a href="<?php echo e(asset('storage/' . $document->file)); ?>" target="_blank"><?php echo e($document->namafile); ?></a></td>
                <td>
                    <a href="<?php echo e(url('/edit-dokumen-pelaksanaan/' . $document->id)); ?>" class="btn btn-warning btn-sm">Edit</a>
                    <form action="<?php echo e(route('deletePelaksanaan', $document->id)); ?>" method="POST" style="display: inline;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger btn-sm">Hapus</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        </table>
    </div>
    <div id="DatatablesPanduanRPS">
        <!-- Tabel CPL di sini -->
        <table class="table table-bordered custom-table-sm" >
                    <thead>
            <tr>
                <th>No</th>
                <th>Program Studi</th>
                <th>Dokumen Formulir Kepuasan</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $panduanRps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($index + 1); ?></td>
                <td><?php echo e($document->nama_prodi); ?></td>
                <td><a href="<?php echo e(asset('storage/' . $document->file)); ?>" target="_blank"><?php echo e($document->namafile); ?></a></td>
                <td>
                    <a href="<?php echo e(url('/edit-dokumen-pelaksanaan/' . $document->id)); ?>" class="btn btn-warning btn-sm">Edit</a>
                    <form action="<?php echo e(route('deletePelaksanaan', $document->id)); ?>" method="POST" style="display: inline;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger btn-sm">Hapus</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        </table>
    </div>
    <div id="DatatablesPanduanMutuSoal">
        <!-- Tabel CPL di sini -->
        <table class="table table-bordered custom-table-sm" >
                    <thead>
            <tr>
                <th>No</th>
                <th>Program Studi</th>
                <th>Dokumen Formulir Kepuasan</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $panduanMutuSoal; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($index + 1); ?></td>
                <td><?php echo e($document->nama_prodi); ?></td>
                <td><a href="<?php echo e(asset('storage/' . $document->file)); ?>" target="_blank"><?php echo e($document->namafile); ?></a></td>
                <td>
                    <a href="<?php echo e(url('/edit-dokumen-pelaksanaan/' . $document->id)); ?>" class="btn btn-warning btn-sm">Edit</a>
                    <form action="<?php echo e(route('deletePelaksanaan', $document->id)); ?>" method="POST" style="display: inline;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger btn-sm">Hapus</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        </table>
    </div>
    <div id="DatatablesPanduanKisi">
        <!-- Tabel CPL di sini -->
        <table class="table table-bordered custom-table-sm" >
                    <thead>
            <tr>
                <th>No</th>
                <th>Program Studi</th>
                <th>Dokumen Formulir Kepuasan</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $panduanKisiKisi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($index + 1); ?></td>
                <td><?php echo e($document->nama_prodi); ?></td>
                <td><a href="<?php echo e(asset('storage/' . $document->file)); ?>" target="_blank"><?php echo e($document->namafile); ?></a></td>
                <td>
                    <a href="<?php echo e(url('/edit-dokumen-pelaksanaan/' . $document->id)); ?>" class="btn btn-warning btn-sm">Edit</a>
                    <form action="<?php echo e(route('deletePelaksanaan', $document->id)); ?>" method="POST" style="display: inline;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger btn-sm">Hapus</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        </table>
    </div>
    <div id="DatatablesFormulirKepuasan">
        <!-- Tabel CPL di sini -->
        <table class="table table-bordered custom-table-sm" >
                    <thead>
            <tr>
                <th>No</th>
                <th>Program Studi</th>
                <th>Dokumen Formulir Kepuasan</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $formulirKepuasan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($index + 1); ?></td>
                <td><?php echo e($document->nama_prodi); ?></td>
                <td><a href="<?php echo e(asset('storage/' . $document->file)); ?>" target="_blank"><?php echo e($document->namafile); ?></a></td>
                <td>
                    <a href="<?php echo e(url('/edit-dokumen-pelaksanaan/' . $document->id)); ?>" class="btn btn-warning btn-sm">Edit</a>
                    <form action="<?php echo e(route('deletePelaksanaan', $document->id)); ?>" method="POST" style="display: inline;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger btn-sm">Hapus</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        </table>
    </div>
    <div id="DatatablesMonitoringLayanan">
        <!-- Tabel CPL di sini -->
        <table class="table table-bordered custom-table-sm" >
                    <thead>
            <tr>
                <th>No</th>
                <th>Program Studi</th>
                <th>Dokumen Formulir Kepuasan</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $monitoringKemahasiswaan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($index + 1); ?></td>
                    <td><?php echo e($document->nama_prodi); ?></td>
                    <td><a href="<?php echo e(asset('storage/' . $document->file)); ?>" target="_blank"><?php echo e($document->namafile); ?></a></td>
                    <td>
                        <a href="<?php echo e(url('/edit-dokumen-pelaksanaan/' . $document->id)); ?>" class="btn btn-warning btn-sm">Edit</a>
                        <form action="<?php echo e(route('deletePelaksanaan', $document->id)); ?>" method="POST" style="display: inline;">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger btn-sm">Hapus</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('User.admin.Pelaksanaan.sidebar_prodi', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SIJAMU_FIP-main\resources\views/User/admin/Pelaksanaan/index_prodi.blade.php ENDPATH**/ ?>