

<?php $__env->startSection('navbar'); ?>
    <div class="layout-menu-toggle navbar-nav align-items-xl-center me-3 me-xl-0 d-xl-none">
        <a class="nav-item nav-link px-0 me-xl-4" href="javascript:void(0)">
            <i class="bx bx-menu bx-sm"></i>
        </a>
    </div>

    <div class="navbar-nav-right d-flex align-items-center" id="navbar-collapse">
        <div class="navbar-nav align-items-center" style="color: #007bff; font-size: 20px; font-weight:bold">Evaluasi</div>

        
        <ul class="navbar-nav flex-row align-items-center ms-auto">
            <!-- User -->
            <li class="nav-item navbar-dropdown dropdown-user dropdown">
                <a class="nav-link dropdown-toggle hide-arrow" href="javascript:void(0);" data-bs-toggle="dropdown">
                    <div class="avatar avatar-online">
                        <img src="<?php echo e(asset('sneat/assets/img/avatars/1.png')); ?>" alt
                            class="w-px-40 h-auto rounded-circle" />
                    </div>
                </a>
                <ul class="dropdown-menu dropdown-menu-end">
                    <li>
                        <a class="dropdown-item" href="#">
                            <div class="d-flex">
                                <div class="flex-shrink-0 me-3">
                                    <div class="avatar avatar-online">
                                        <img src="<?php echo e(asset('sneat/assets/img/avatars/1.png')); ?>" alt
                                            class="w-px-40 h-auto rounded-circle" />
                                    </div>
                                </div>
                                <div class="flex-grow-1">
                                    <span class="fw-semibold d-block">John Doe</span>
                                    <small class="text-muted">Admin</small>
                                </div>
                            </div>
                        </a>
                    </li>
                    <li>
                        <div class="dropdown-divider"></div>
                    </li>
                    <li>
                        <a class="dropdown-item" href="#">
                            <i class="bx bx-user me-2"></i>
                            <span class="align-middle">My Profile</span>
                        </a>
                    </li>
                    <li>
                        <a class="dropdown-item" href="#">
                            <i class="bx bx-cog me-2"></i>
                            <span class="align-middle">Settings</span>
                        </a>
                    </li>
                    <li>
                        <div class="dropdown-divider"></div>
                    </li>
                    <li>
                        <a class="dropdown-item" href="<?php echo e(route('logout')); ?>">
                            <i class="bx bx-power-off me-2"></i>
                            <span class="align-middle">Log Out</span>
                        </a>
                    </li>
                </ul>
            </li>
            <!--/ User -->
        </ul>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <h5 class="card-header">Audit Mutu Internal (AMI)
            <button type="button" class="btn btn-outline-secondary dropdown-toggle" data-bs-toggle="dropdown"
                aria-expanded="false">
                Tahun Akademik (TA)
            </button>
            <ul class="dropdown-menu">
                <li><a class="dropdown-item" href="javascript:void(0);">2022-2023</a></li>
                <li><a class="dropdown-item" href="javascript:void(0);">2023-2024</a></li>
                <li><a class="dropdown-item" href="javascript:void(0);">2024-2025</a></li>
            </ul>
        </h5>
        <div class="table text-nowrap" id="horizontal-example" style="height: 200px;">
            <table class="table table-bordered">
                <thead class="table-purple">
                    <tr>
                        <th>Nama Dokumen</th>
                        <th>Program Studi</th>
                        <th>Tanggal Terakhir Dilakukan</th>
                        <th>Tanggal Diperbarui</th>
                        <th>Unggahan</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody class="table-border-bottom-0">
                    <?php $__currentLoopData = $evaluasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><i></i><?php echo e($row->nama_dokumen); ?></td>
                        <td><i></i><?php echo e($row->program_studi); ?></td>
                        <td><i></i><?php echo e($row->tanggal_terakhir_dilakukan); ?></td>
                        <td><i></i><?php echo e($row->tanggal_diperbarui); ?></td>
                        <td>
                            <?php if($row->unggahan): ?>
                            <!-- Hanya berlaku jika dihosting-->
                            
                            <a href="../storage/evaluasi/<?php echo e($row->unggahan); ?>"
                                class="badge bg-label-info me-1" target="_blank" >
                                <i class="bi bi-link-45deg">Dokumen</i>
                            </a>

                            <?php else: ?>
                                <p>Masih dalam proses</p>
                            <?php endif; ?>
                        </td>
                        <td>
                            <div class="dropdown">
                                <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown">
                                    <i class="bx bx-dots-vertical-rounded"></i>
                                </button>
                                <div class="dropdown-menu">
                                    <div>
                                        <a class="dropdown-item"
                                            href="<?php echo e(route('editDokumenEvaluasi', $row->id_evaluasi)); ?>"><i
                                                class="bx bx-edit-alt me-1"></i>
                                            Ubah</a>
                                    </div>
                                    <div>
                                        <form method="POST"
                                            action="<?php echo e(route('hapusDokumenEvaluasi', $row->id_evaluasi)); ?>">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button class="dropdown-item btn btn-outline-danger"><i
                                                    class="bx bx-trash me-1"></i>
                                                Hapus</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
    <div class="demo-inline-spacing">
        <button type="button" class="btn btn-light" onclick="window.location.href='<?php echo e(route('tambahDokumenAMI')); ?>'">+
            Tambah Laporan Evaluasi</button>
        <?php if(session('success')): ?>
            <div><?php echo e(@session('success')); ?></div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SIJAMU_FIP-main\resources\views/User/admin/Evaluasi/index_evaluasi.blade.php ENDPATH**/ ?>