<?php $__env->startSection('navbar'); ?>
    <div class="layout-menu-toggle navbar-nav align-items-xl-center me-3 me-xl-0 d-xl-none">
        <a class="nav-item nav-link px-0 me-xl-4" href="javascript:void(0)">
            <i class="bx bx-menu bx-sm"></i>
        </a>
    </div>

    <div class="navbar-nav-right d-flex align-items-center" id="navbar-collapse">
        <div class="navbar-nav align-items-center">
            <div class="nav-items d-flex align-item-center">Edit Dokumen Pelaksanaan</div>
        </div>
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('content'); ?>
        <div class="row">

            <div class="col-xl">
                <div class="card mb-4">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h5 class="mb-0"></h5>
                    </div>
                    <div class="card-body">
                        <form method="POST" action="<?php echo e(url('update-dokumen-pelaksanaan/' . $pelaksanaan->id)); ?>" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <!-- Nama Dokumen -->
                            <div class="mb-3">
                                <label class="form-label" for="bx bx-file">Nama Dokumen</label>
                                <div class="input-group input-group-merge">
                                    <span id="basic-icon-default-fullname2" class="input-group-text"><i class="bx bx-file"></i></span>
                                    <input type="text" class="form-control" id="bx bx-file" name="nama_filep1" placeholder="Nama Dokumen" required
                                           value="<?php echo e($pelaksanaan->namafile); ?>" />
                                </div>
                            </div>

                            <!-- Kategori -->
                            <div class="mb-3">
                                <label for="kategori" class="form-label">Kategori</label>
                                <select class="form-select" id="kategori" name="kategori" required>
                                    <option value="">Pilih Kategori</option>
                                    <option value="Renstra Program Studi" <?php echo e($pelaksanaan->kategori == 'Renstra Program Studi' ? 'selected' : ''); ?>>Renstra Program Studi</option>
                                    <option value="Laporan Kinerja Program Studi" <?php echo e($pelaksanaan->kategori == 'Laporan Kinerja Program Studi' ? 'selected' : ''); ?>>Laporan Kinerja Program Studi</option>
                                    <option value="Dokumen Kurikulum" <?php echo e($pelaksanaan->kategori == 'Dokumen Kurikulum' ? 'selected' : ''); ?>>Dokumen Kurikulum</option>
                                    <option value="Rencana Pembelajaran Semester (RPS)" <?php echo e($pelaksanaan->kategori == 'Rencana Pembelajaran Semester (RPS)' ? 'selected' : ''); ?>>Rencana Pembelajaran Semester (RPS)</option>
                                    <option value="Dokumen Monitoring dan Evaluasi Kegiatan Program MBKM" <?php echo e($pelaksanaan->kategori == 'Dokumen Monitoring dan Evaluasi Kegiatan Program MBKM' ? 'selected' : ''); ?>>Dokumen Monitoring dan Evaluasi Kegiatan Program MBKM</option>
                                    <option value="Capaian Pembelajaran Lulusan (CPL)" <?php echo e($pelaksanaan->kategori == 'Capaian Pembelajaran Lulusan (CPL)' ? 'selected' : ''); ?>>Capaian Pembelajaran Lulusan (CPL)</option>
                                    <option value="Panduan RPS" <?php echo e($pelaksanaan->kategori == 'Panduan RPS' ? 'selected' : ''); ?>>Panduan RPS</option>
                                    <option value="Panduan Mutu Soal" <?php echo e($pelaksanaan->kategori == 'Panduan Mutu Soal' ? 'selected' : ''); ?>>Panduan Mutu Soal</option>
                                    <option value="Panduan Kisi Kisi Soal" <?php echo e($pelaksanaan->kategori == 'Panduan Kisi Kisi Soal' ? 'selected' : ''); ?>>Panduan Kisi Kisi Soal</option>
                                    <option value="Formulir Kepuasan Mahasiswa" <?php echo e($pelaksanaan->kategori == 'Formulir Kepuasan Mahasiswa' ? 'selected' : ''); ?>>Formulir Kepuasan Mahasiswa</option>
                                    <option value="Dokumen Monitoring dan Evaluasi Ketercapaian Standar Layanan Kemahasiswaan" <?php echo e($pelaksanaan->kategori == 'Dokumen Monitoring dan Evaluasi Ketercapaian Standar Layanan Kemahasiswaan' ? 'selected' : ''); ?>>Dokumen Monitoring dan Evaluasi Ketercapaian Standar Layanan Kemahasiswaan</option>
                                </select>
                            </div>

                            <!-- Tahun -->
                            <div class="mb-3">
                                <label for="tahun" class="form-label">Tahun</label>
                                <input type="number" class="form-control" id="tahun" name="tahun" placeholder="Tahun" required min="1900" max="2099"
                                       value="<?php echo e($pelaksanaan->tahun); ?>" />
                            </div>

                            <!-- Nama Program Studi -->
                            <div class="mb-3">
                                <label for="nama_prodi" class="form-label">Nama Program Studi</label>
                                <select class="form-select" id="nama_prodi" name="nama_prodi" required>
                                    <option value="">Pilih Program Studi</option>
                                    <?php $__currentLoopData = $prodi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($item->id_prodi); ?>" <?php echo e($pelaksanaan->namaprodi == $item->id_prodi ? 'selected' : ''); ?>>
                                            <?php echo e($item->nama_prodi); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <!-- Pilih Dokumen -->
                            <div class="mb-3">
                                <label for="formFileMultiple" class="form-label">Pilih Dokumen</label>
                                <input class="form-control" type="file" name="files[]" id="formFileMultiple" multiple />
                                <p class="form-text text-muted">Unggah ulang dokumen jika ingin mengubah file yang sudah ada.</p>
                            </div>

                            <!-- Kirim -->
                            <button type="submit" class="btn btn-primary">Kirim</button>
                        </form>
                    </div>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SIJAMU_FIP-main\resources\views/User/admin/Pelaksanaan/edit_dokumen_pelaksanaan.blade.php ENDPATH**/ ?>