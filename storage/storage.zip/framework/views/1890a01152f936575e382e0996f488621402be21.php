<?php $__env->startSection('tabel-unggah-dokumen'); ?>
<a href="/tambah-dokumen-pelaksanaan-fakultas" class="btn btn-primary mb-3">Tambah Dokumen</a>

<div id="DatatablesRenstraProgramStudinya">
    <!-- Tabel CPL di sini -->
    <table class="table table-bordered custom-table-sm" >
                <thead>
        <tr>
            <th>No</th>
            <th>Nama Dokumen</th>
            <th>Dokumen Formulir Kepuasan</th>
            <th>Aksi</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $renstraFakultas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($index + 1); ?></td>
                <td><?php echo e($document->namafile); ?></td>
                <td><a href="<?php echo e(asset('storage/' . $document->file)); ?>" target="_blank"><?php echo e($document->namafile); ?></a></td>
                <td>
                    <a href="<?php echo e(url('/edit-dokumen-pelaksanaan-fakultas/' . $document->id)); ?>" class="btn btn-warning btn-sm">Edit</a>
                    <form action="<?php echo e(route('deletePelaksanaanFakultas', $document->id)); ?>" method="POST" style="display: inline;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger btn-sm">Hapus</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
    </table>
</div>
<div id="DatatablesLaporanKinerjaFakultas">
    <!-- Tabel CPL di sini -->
    <table class="table table-bordered custom-table-sm" >
                <thead>
        <tr>
            <th>No</th>
            <th>Program Studi</th>
            <th>Dokumen Formulir Kepuasan</th>
            <th>Aksi</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $laporanKinerjaFakultas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($index + 1); ?></td>
                <td><?php echo e($document->namafile); ?></td>
                <td><a href="<?php echo e(asset('storage/' . $document->file)); ?>" target="_blank"><?php echo e($document->namafile); ?></a></td>
                <td>
                    <a href="<?php echo e(url('/edit-dokumen-pelaksanaan-fakultas/' . $document->id)); ?>" class="btn btn-warning btn-sm">Edit</a>
                    <form action="<?php echo e(route('deletePelaksanaanFakultas', $document->id)); ?>" method="POST" style="display: inline;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger btn-sm">Hapus</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('User.admin.Pelaksanaan.sidebar_fakultas', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SIJAMU_FIP-main\resources\views/User/admin/Pelaksanaan/index_fakultas.blade.php ENDPATH**/ ?>