<!DOCTYPE html>
<html lang="en" data-assets-path="<?php echo e(asset('sneat/assets/assets/')); ?>">


<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <title>SIJAMU FIP | Halaman Login</title>
    <!-- Favicon -->
    <link rel="icon" type="image/x-icon" href="<?php echo e(asset('sneat/assets/img/favicon/LogoFIP.png')); ?>" />
    <!-- Font Awesome icons (free version)-->
    <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
    <!-- Google fonts-->
    <link rel="preconnect" href="https://fonts.gstatic.com" />
    <link href="https://fonts.googleapis.com/css2?family=Tinos:ital,wght@0,400;0,700;1,400;1,700&amp;display=swap"
        rel="stylesheet" />
    <link
        href="https://fonts.googleapis.com/css2?family=DM+Sans:ital,wght@0,400;0,500;0,700;1,400;1,500;1,700&amp;display=swap"
        rel="stylesheet" />
    <!-- Core theme CSS (includes Bootstrap)-->
    <link rel="stylesheet" href="<?php echo e(asset('sneat/assets/assets/img/bg-mobile-fallback.jpg')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('sneat/assets/assets/mp4/bg.mp4')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('sneat/assets/css/styles.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('sneat/assets/js/scripts.js')); ?>" />
</head>

<body>
    <!-- Background Video-->
    <video class="bg-video" playsinline="playsinline" autoplay="autoplay" muted="muted" loop="loop">
        <source src="<?php echo e(asset('sneat/assets/assets/mp4/bg.mp4')); ?>" type="video/mp4" />
    </video>
    <!-- Masthead-->
    <div class="masthead">
        <div class="masthead-content text-white">
            <div class="container-fluid px-4 px-lg-0">
                <?php echo $__env->yieldContent('index-content'); ?>
            </div>
        </div>
    </div>
    <!-- tombol Daftar Akun, Panduan Pengguna, Info-->
    <!-- For more icon options, visit https://fontawesome.com/icons?d=gallery&p=2&s=brands-->
    <div class="social-icons">
        <div class="d-flex flex-row flex-lg-column justify-content-center align-items-center h-100 mt-3 mt-lg-0">
            <a type="button" class="btn btn-dark m-3" href="#!" data-bs-toggle="tooltip" data-bs-offset="0,4"
                data-bs-placement="right" data-bs-html="true"
                title="s"><i
                    class="fa-solid fa-user-plus" style="color: #fefefe;"></i></a>

            <a class="btn btn-dark m-3" href="#!"><i class="fa-solid fa-book" style="color: #fefefe;"></i></a>

            <a class="btn btn-dark m-3" href="#!"><i class="fa-solid fa-circle-info"
                    style="color: #fafafa;"></i></a>
        </div>
    </div>
    <!-- Bootstrap core JS-->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Core theme JS-->
    <script src="js/scripts.js"></script>
    <!-- * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *-->
    <!-- * *                               SB Forms JS                               * *-->
    <!-- * * Activate your form at https://startbootstrap.com/solution/contact-forms * *-->
    <!-- * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *-->
    <script src="https://cdn.startbootstrap.com/sb-forms-latest.js"></script>
</body>

</html>
<?php /**PATH C:\ProjectSIJAMUFIP-laravel9\SIJAMU_FIP\resources\views/layout/index-login-auth.blade.php ENDPATH**/ ?>