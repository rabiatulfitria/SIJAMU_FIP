<?php $__env->startSection('navbar'); ?>
    <div class="layout-menu-toggle navbar-nav align-items-xl-center me-xl-0 d-xl-none me-3">
        <a class="nav-item nav-link me-xl-4 px-0" href="javascript:void(0)">
            <i class="bx bx-menu bx-sm"></i>
        </a>
    </div>

    <div class="navbar-nav-right d-flex align-items-center" id="navbar-collapse">
        <div class="navbar-nav align-items-center" style="color: #007bff; font-size: 20px; font-weight:bold">Penetapan</div>

        <ul class="navbar-nav align-items-center ms-auto flex-row">
            <!-- User -->
            <li class="nav-item navbar-dropdown dropdown-user dropdown">
                <a class="nav-link dropdown-toggle hide-arrow" href="javascript:void(0);" data-bs-toggle="dropdown">
                    <div class="avatar avatar-online">
                        <img src="<?php echo e(asset('sneat/assets/img/avatars/1.png')); ?>" alt
                            class="w-px-40 rounded-circle h-auto" />
                    </div>
                </a>
                <ul class="dropdown-menu dropdown-menu-end">
                    <li>
                        <a class="dropdown-item" href="#">
                            <div class="d-flex">
                                <div class="me-3 flex-shrink-0">
                                    <div class="avatar avatar-online">
                                        <img src="<?php echo e(asset('sneat/assets/img/avatars/1.png')); ?>" alt
                                            class="w-px-40 rounded-circle h-auto" />
                                    </div>
                                </div>
                                <div class="flex-grow-1">
                                    <span class="fw-semibold d-block">John Doe</span>
                                    <small class="text-muted">Admin</small>
                                </div>
                            </div>
                        </a>
                    </li>
                    <li>
                        <div class="dropdown-divider"></div>
                    </li>
                    <li>
                        <a class="dropdown-item" href="#">
                            <i class="bx bx-user me-2"></i>
                            <span class="align-middle">My Profile</span>
                        </a>
                    </li>
                    <li>
                        <a class="dropdown-item" href="#">
                            <i class="bx bx-cog me-2"></i>
                            <span class="align-middle">Settings</span>
                        </a>
                    </li>
                    <li>
                        <div class="dropdown-divider"></div>
                    </li>
                    <li>
                        <a class="dropdown-item" href="<?php echo e(route('logout')); ?>">
                            <i class="bx bx-power-off me-2"></i>
                            <span class="align-middle">Log Out</span>
                        </a>
                    </li>
                </ul>
            </li>
            <!--/ User -->
        </ul>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <h5 class="card-header">Standar Yang Ditetapkan Institusi</h5>
        <div class="table-responsive text-nowrap">
            <table class="table">
                <thead class="table-purple">
                    <tr>
                        <th style="padding-left: 35px">Nama Dokumen</th>
                        <th style="padding-left: 35px">Kategori</th>
                        <th style="padding-left: 35px">Tahun</th>
                        <th style="padding-left: 35px">Nama Program Studi</th>
                        <th style="padding-left: 10px">Unggahan</th>
                        <?php if(Auth::user() && (Auth::user()->level == 'Admin' || Auth::user()->level == 'Jaminan Mutu' || Auth::user()->level == 'Koorprodi')): ?>
                            <th>Aksi</th>
                        <?php endif; ?>
                    </tr>
                </thead>
                <tbody class="table-border-bottom-0">
                    <?php $__currentLoopData = $dokumenp1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td style="padding-left: 20px"><i class="me-3"></i>
                                <strong><?php echo e($row->namafile); ?></strong>
                            </td>
                            <td><?php echo e($row->kategori); ?></td>
                            <td><?php echo e($row->tahun); ?></td>
                            <td><?php echo e($row->nama_prodi); ?></td>
                            <td>
                                <?php if($row->file): ?>
                                    <!-- Link ke dokumen -->
                                    <a href="<?php echo e(asset('storage/' . $row->file)); ?>" class="badge bg-label-info me-1" target="_blank">
                                        <i class="bi bi-link-45deg">Dokumen</i>
                                    </a>
                                <?php else: ?>
                                    <p>Masih dalam proses</p>
                                <?php endif; ?>
                            </td>
                            <?php if(Auth::user() && (Auth::user()->level == 'Admin' || Auth::user()->level == 'Jaminan Mutu' || Auth::user()->level == 'Koorprodi')): ?>
                            <td>
                                <div class="dropdown">
                                    <button type="button" class="btn dropdown-toggle hide-arrow p-0"
                                        data-bs-toggle="dropdown">
                                        <i class="bx bx-dots-vertical-rounded"></i>
                                    </button>
                                    <div class="dropdown-menu">
                                        <?php if(session('success')): ?>
                                            <div><?php echo e(@session('success')); ?></div>
                                        <?php endif; ?>
                                        <a class="dropdown-item"
                                            onclick="window.location.href='<?php echo e(route('editDataStandar', ['id' => $row->id_standarinstitut])); ?>'">
                                            <i class="bx bx-edit-alt me-1"></i> Ubah Data
                                        </a>
                                        <div>
                                            <form method="POST"
                                                action="<?php echo e(route('hapusDokumenStandar', $row->id_standarinstitut)); ?>">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button class="dropdown-item btn btn-outline-danger"><i
                                                        class="bx bx-trash me-1"></i>
                                                    Hapus</button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </td>
                            <?php endif; ?>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php if(Auth::user() && (Auth::user()->level == 'Admin' || Auth::user()->level == 'Jaminan Mutu' || Auth::user()->level == 'Koorprodi')): ?>
    <div class="demo-inline-spacing">
        <button type="button" class="btn btn-light" onclick="window.location.href='<?php echo e(route('tambahStandar')); ?>'">
            + Tambah Standar
        </button>
        <?php if(session('success')): ?>
            <div><?php echo e(@session('success')); ?></div>
        <?php endif; ?>
    </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\ProjectSIJAMUFIP-laravel9\SIJAMU_FIP\resources\views/User/admin/Penetapan/standarinstitusi.blade.php ENDPATH**/ ?>