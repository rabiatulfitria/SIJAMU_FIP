<?php $__env->startSection('navbar'); ?>
<div class="layout-menu-toggle navbar-nav align-items-xl-center me-3 me-xl-0 d-xl-none">
    <a class="nav-item nav-link px-0 me-xl-4" href="javascript:void(0)">
        <i class="bx bx-menu bx-sm"></i>
    </a>
</div>

<div class="navbar-nav-right d-flex align-items-center" id="navbar-collapse">
    <div class="navbar-nav align-items-center">
        <div class="nav-items d-flex align-item-center">Tim Jaminan Mutu Fakultas</div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">

        <div class="col-xl">
            <div class="card mb-4">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0"></h5>
                </div>
                <div class="card-body">
                    <form method="POST" action="/TimPenjaminanMutu/<?php echo e($oldData->id); ?>/updateTimJAMU">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <div class="mb-3">
                            <label class="form-label" for="basic-icon-default-fullname">NIP</label>
                            <div class="input-group input-group-merge">
                                <span id="basic-icon-default-fullname2" class="input-group-text"><i
                                        class="bx bx-user"></i></span>
                                <input type="text" class="form-control" id="basic-icon-default-fullname"
                                    name="nip"
                                    value="<?php echo e($oldData->nip); ?>"
                                    placeholder="Nomor Induk Pegawai" aria-label="John Doe"
                                    aria-describedby="basic-icon-default-fullname2" />
                            </div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label" for="basic-icon-default-fullname">Nama</label>
                            <div class="input-group input-group-merge">
                                <span id="basic-icon-default-fullname2" class="input-group-text"><i
                                        class="bx bx-user"></i></span>
                                <input type="text" class="form-control" id="basic-icon-default-fullname"
                                    name="nama"
                                    value="<?php echo e($oldData->nama); ?>"
                                    placeholder="Nama Lengkap" aria-label="John Doe"
                                    aria-describedby="basic-icon-default-fullname2" />
                            </div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label" for="basic-icon-default-email">Email</label>
                            <div class="input-group input-group-merge">
                                <span class="input-group-text"><i class="bx bx-envelope"></i></span>
                                <input type="text" id="basic-icon-default-email" class="form-control"
                                    name="email"
                                    value="<?php echo e($oldData->email); ?>"
                                    placeholder="john.doe" aria-label="john.doe"
                                    aria-describedby="basic-icon-default-email2" />

                            </div>
                            <div class="form-text"></div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label" for="box-icon-id-card">Penanggung Jawab</label>
                            <div class="input-group input-group-merge">
                                <span id="" class="input-group-text"><i
                                        class="bx bx-id-card"></i></span>
                                <input type="text" id="basic-icon-default-fullname2" class="form-control"
                                    name="PJ"
                                    value="<?php echo e($oldData->PJ); ?>"
                                    placeholder="Selaku" aria-label=""
                                    aria-describedby="basic-icon-default-fullname2" />
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary">Ubah</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\SIJAMU_FIP-main\resources\views/User/admin/TimJMF/editTimjamu.blade.php ENDPATH**/ ?>