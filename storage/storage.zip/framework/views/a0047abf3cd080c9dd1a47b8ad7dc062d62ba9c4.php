<?php $__env->startSection('content'); ?>
          <!-- Register -->
          <div class="card">
            <div class="card-body">
                <?php echo $__env->make('_partials.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
              <!-- Logo -->
              <div class="app-brand justify-content-center">
                <a href="index.html" class="app-brand-link gap-2" style="display: flex;flex-direction:column!important;">
                  <span class="app-brand-logo demo">
                    <img src="<?php echo e(asset('sneat/assets/img/favicon/LogoFIP.png')); ?>" alt="">
                  </span>
                  <span class="app-brand-text demo text-body fw-bolder" style="text-transform: uppercase!important">SIJAMU FIP</span>
                </a>
              </div>
              <!-- /Logo -->
              <h4 class="mb-2 text-center">HALAMAN LOGIN</h4>
              <p class="mb-4 text-center">Silahkan Masukkan Kredensial Anda Untuk Login</p>

              <form id="formAuthentication" class="mb-3" action="<?php echo e(route('login')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="mb-3">
                  <label for="email" class="form-label">Email</label>
                  <input
                    type="text"
                    class="form-control"
                    id="email"
                    name="email"
                    placeholder="Masukkan Email"
                    autofocus
                  />
                </div>
                <div class="mb-3 form-password-toggle">
                  <div class="d-flex justify-content-between">
                    <label class="form-label" for="password">Password</label>
                  </div>
                  <div class="input-group input-group-merge">
                    <input
                      type="password"
                      id="password"
                      class="form-control"
                      name="password"
                      placeholder="Masukkan Password"
                      aria-describedby="password"
                    />
                    <span class="input-group-text cursor-pointer"><i class="bx bx-hide"></i></span>
                  </div>
                </div>
                <div class="mb-3">
                  <button class="btn btn-primary d-grid w-100" type="submit">LOGIN</button>
                </div>
              </form>

            </div>
          </div>
          <!-- /Register -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\ProjectSIJAMUFIP-laravel9\SIJAMU_FIP\resources\views/auth/login.blade.php ENDPATH**/ ?>